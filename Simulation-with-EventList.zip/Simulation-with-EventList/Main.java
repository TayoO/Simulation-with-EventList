
public class Main extends EventHandler {
	private static SimSystem s;
	public static void main(String [] args) {
		s = new SimSystem();
		System.out.println("program terminates");
	}
}

