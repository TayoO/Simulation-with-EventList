
public class EventHandler {
	protected void handleEvent(Event e){}
}
