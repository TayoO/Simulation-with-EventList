
public class Event {
	public double time;
	public EventHandler target;
	public int action;
	public int data;
	public double totalDelay;
	
	public static int USER_REQ = 0;
	public static int NEW_REQ = 1;
	public static int SERVE_START = 2;
	public static int SERVE_END = 3;
	public static int STAT = 4;
}
